/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rpc4;



public interface CalculatorService4 {
    Object calculate_pi();
    Object add(double a, double b);
    Object sort(double[] array);
    Object matrix_multiply(double[][] a, double[][] b);
}
