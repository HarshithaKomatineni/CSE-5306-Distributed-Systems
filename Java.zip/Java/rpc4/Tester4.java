/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rpc4;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.Arrays;

public class Tester4 {

    public static void main(String[] args) throws IOException {
        //run RPC server
        new Thread(new Runnable() {
            public void run() {
                try {
                    RPCServer4 serviceServer = new RPCServer4(8888);
                    serviceServer.register(CalculatorService4.class, CalculatorImpl4.class);
                    serviceServer.start();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();

        //run client
        CalculatorService4 service = Client4.getRemoteProxyObj(CalculatorService4.class, new InetSocketAddress("localhost", 8888));
        double[] array = {3, 2, 1, 5, 9, 7};
        double[][] a = {{1, 2, 3}, {1, 2, 3}, {1, 2, 3}};
        double[][] b = {{1, 2, 3}, {1, 2, 3}, {1, 2, 3}};
        double[][] c = new double[3][3];
        
        System.out.println("Send computation request as deferred synchronous");
        Object key_1 = service.calculate_pi();
        Object key_2 = service.add(3, 5);
        Object key_3 = service.sort(array);
        Object key_4 = service.matrix_multiply(a, b);
        
        //get PI calculation
        double pi = (double)Client4.requestComputationResult((Integer)key_1, new InetSocketAddress("localhost", 8888));
        System.out.println();
        System.out.println("PI Calculation: " + pi);
        
        //request add calculation
        double add = (double)Client4.requestComputationResult((Integer)key_2, new InetSocketAddress("localhost", 8888));
        System.out.println();
        System.out.println("ADD Calculation: " + add);

        //sort array
        array = (double[])Client4.requestComputationResult((Integer)key_3, new InetSocketAddress("localhost", 8888));
        System.out.println();
        System.out.println("Sort array");
        System.out.println("Input array: " + Arrays.toString(array));
        System.out.println("Sort array: " + Arrays.toString(array));

        //matrix calculation
        c = (double[][])Client4.requestComputationResult((Integer)key_4, new InetSocketAddress("localhost", 8888));
        System.out.println();
        System.out.println("Multiple matrix");
        System.out.println("Input a: " + Arrays.toString(a[0]) + "," + Arrays.toString(a[1]) + "," + Arrays.toString(a[2]));
        System.out.println("Input b: " + Arrays.toString(b[0]) + "," + Arrays.toString(b[1]) + "," + Arrays.toString(b[2]));
        System.out.println("Result: " + Arrays.toString(c[0]) + "," + Arrays.toString(c[1]) + "," + Arrays.toString(c[2]));
        
        Client4.closeConnection();
    }
}
