/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rpc4;

import java.util.Arrays;

public class CalculatorImpl4 implements CalculatorService4 {

    public Object calculate_pi() {
        return Math.PI;
    }

    public Object add(double a, double b) {
        return a + b;
    }

    public Object sort(double[] array) {
        if (array == null) {
            return array;
        }
        Arrays.sort(array);
        return array;
    }

    public Object matrix_multiply(double[][] a, double[][] b) {
       return multiple(a, b);
    }

    private double[][] multiple(double[][] a, double[][] b) {
        
        int row = a.length;
        int col = a[0].length;
        
        double c[][] = new double[row][col];
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                c[i][j] = 0;
                for (int k = 0; k < 3; k++) {
                    c[i][j] += a[i][k] * b[k][j];
                } 
            }
        }
        return c;
    }
}
