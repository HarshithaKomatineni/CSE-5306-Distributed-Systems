/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rpc4;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.net.InetSocketAddress;
import java.net.Socket;

public class Client4<T> {

    private static Socket socket;
    private static ObjectOutputStream output = null;
    private static ObjectInputStream input = null;

    public static void closeConnection() {
        try {
            if (socket != null) {
                socket.close();
            }
            if (output != null) {
                output.close();
            }
            if (input != null) {
                input.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Object requestComputationResult(int key, final InetSocketAddress addr) {
        try {
            if (socket == null) {
                socket = new Socket();
                socket.connect(addr);
                output = new ObjectOutputStream(socket.getOutputStream());
                input = new ObjectInputStream(socket.getInputStream());
            }
            output.writeInt(key);
            output.flush();
            return input.readObject();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static <T> T getRemoteProxyObj(final Class<?> serviceInterface, final InetSocketAddress addr) {
        return (T) Proxy.newProxyInstance(serviceInterface.getClassLoader(), new Class<?>[]{serviceInterface}, new InvocationHandler() {

            public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                try {
                    if (socket == null) {
                        socket = new Socket();
                        socket.connect(addr);
                        output = new ObjectOutputStream(socket.getOutputStream());
                        input = new ObjectInputStream(socket.getInputStream());
                    }
                    output.writeInt(-1);
                    //send computation interface
                    output.writeUTF(serviceInterface.getName());
                    //send method name
                    output.writeUTF(method.getName());
                    //send method paramter type
                    output.writeObject(method.getParameterTypes());
                    output.writeObject(args);
                    output.flush();
                    //receive result
                    Object result = input.readObject();
                    return result;
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return null;
            }
        });
    }
}
