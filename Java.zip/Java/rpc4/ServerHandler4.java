/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rpc4;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Method;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

public class ServerHandler4 implements Runnable {

    Socket clent = null;
    RPCServer4 server;
    AtomicInteger count = new AtomicInteger(0);
    Map<Integer, Object> computtion_table = new HashMap<>();

    public ServerHandler4(RPCServer4 server, Socket client) {
        this.clent = client;
        this.server = server;
    }

    public void run() {
        ObjectInputStream input = null;
        ObjectOutputStream output = null;
        try {
            input = new ObjectInputStream(clent.getInputStream());
            output = new ObjectOutputStream(clent.getOutputStream());

            while (true) {
                int option = input.readInt();
                if (option < 0) {
                    //request computation
                    String serviceName = input.readUTF();
                    String methodName = input.readUTF();
                    Class<?>[] parameterTypes = (Class<?>[]) input.readObject();
                    Object[] arguments = (Object[]) input.readObject();
                    Class serviceClass = server.getRegister().get(serviceName);

                    if (serviceClass == null) {
                        throw new ClassNotFoundException(serviceName + " not found");
                    }
                    Method method = serviceClass.getMethod(methodName, parameterTypes);
                    Object result = method.invoke(serviceClass.newInstance(), arguments);
                    //save result to computation table
                    Integer key = count.incrementAndGet();
                    computtion_table.put(key, result);
                    //send key to client
                    output.writeObject(key);
                    output.flush();
                } else {
                    //request computation result
                    Object result = computtion_table.get(option);
                    //send result to client
                    output.writeObject(result);
                    output.flush();
                }
            }
        } catch (Exception e) {

        } finally {
            if (output != null) {
                try {
                    output.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (input != null) {
                try {
                    input.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (clent != null) {
                try {
                    clent.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }
}
