/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rpc3;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.Arrays;

public class Tester3 {

    public static void main(String[] args) throws IOException {
        //run RPC server
        new Thread(new Runnable() {
            public void run() {
                try {
                    RPCServer serviceServer = new RPCServer(7777);
                    serviceServer.register(CalculatorService.class, CalculatorImpl.class);
                    serviceServer.start();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();

        //run client
        //client is working as asynchronous , that is, it sed request and wait for result
        //below show each request testing
        CalculatorService service = Client.getRemoteProxyObj(CalculatorService.class, new InetSocketAddress("localhost", 7777));

        //request PI calculation
        System.out.println();
        System.out.println("PI Calculation");
        System.out.println("PI: " + service.calculate_pi());

        //request add calculation
        System.out.println();
        System.out.println("ADD Calculation");
        System.out.println("Add calculation: 3 + 5 = " + service.add(3, 5));
        //sort array
        double[] array = {3, 2, 1, 5, 9, 7};
        System.out.println();
        System.out.println("Sort array");
        System.out.println("Input array: " + Arrays.toString(array));
        array = service.sort(array);
        System.out.println("Sort array: " + Arrays.toString(array));

        //matrix calculation
        double[][] a = {{1, 2, 3}, {1, 2, 3}, {1, 2, 3}};
        double[][] b = {{1, 2, 3}, {1, 2, 3}, {1, 2, 3}};
        double[][] c = new double[3][3];

        System.out.println();
        System.out.println("Multiple matrix");
        System.out.println("Input a: " + Arrays.toString(a[0]) + "," + Arrays.toString(a[1]) + "," + Arrays.toString(a[2]));
        System.out.println("Input b: " + Arrays.toString(b[0]) + "," + Arrays.toString(b[1]) + "," + Arrays.toString(b[2]));
        c = service.matrix_multiply(a, b);
        
        System.out.println("Result: " + Arrays.toString(c[0]) + "," + Arrays.toString(c[1]) + "," + Arrays.toString(c[2]));
    }
}
