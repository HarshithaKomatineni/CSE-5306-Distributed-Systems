/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rpc3;


public interface CalculatorService {
    double calculate_pi();
    double add(double a, double b);
    double[] sort(double[] array);
    double[][] matrix_multiply(double[][] a, double[][] b);
}
