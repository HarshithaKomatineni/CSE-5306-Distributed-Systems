package dist2pc;

import javax.swing.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Utils {

    public static String IP = "localhost";
    public static int PORT = 9989;
    public static final String COORDINATOR_NAME = "COORDINATOR";

    public static final String GET = "GET";
    public static final String POST = "POST";

    public static final int COORDINATE_REQUEST = 1;
    public static final int PARTICIPANT_REQUEST = 2;
    public static final int COORDINATE_CONNECTION_REQUEST = 3;
    public static final int PARTICIPANT_CONNECTION_REQUEST = 4;

    public static final String INIT = "INIT",
            READY = "READY",
            COMMIT = "COMMIT",
            ABORT = "ABORT",
            CONNECT = "CONNECT",
            GLOBAL_ABORT = "GLOBAL_ABORT",
            GLOBAL_COMMIT = "GLOBAL_COMMIT";

    public static Message generateMessage(int type, String method, String request, String username){
        Message message = new Message();
        SimpleDateFormat ft = new SimpleDateFormat("yyyy MM dd HH:mm:ss", Locale.getDefault());
        message.setType(type);
        message.setMethod(method);
        message.setRequest(request);
        message.setUsername(username);
        message.setDate(ft.format(new Date()));

        return message;
    }

    public static void showMessage(Component component, String message){
        JOptionPane.showMessageDialog(component, message);
    }
}
