package dist2pc;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class Server {

    private ServerSocket ss;
    private ArrayList<String> userNames;

    private ArrayList<ObjectOutputStream> streams;
    private ObjectOutputStream coordinatorStream;

    public static void main(String[] args) {
        Server server = new Server();
        server.startServerConnection();
    }

    public Server() {

    }

    public void startServerConnection() {

        try {
            ss = new ServerSocket(Utils.PORT);
            userNames = new ArrayList<>();
            streams = new ArrayList<>();
            System.out.println("Server is running...");

            while (true) {
                //listen client connection
                Socket client = ss.accept();
                ServerClientHandler sch = new ServerClientHandler(client);
                sch.start();
            }
        } catch (IOException e) {
            e.getMessage();
        }
    }

    private void SendDataAllParticipants(int type, String request, String username) {
        for (ObjectOutputStream dataOutputStream : streams) {
            try {
                Message message = Utils.generateMessage(type, Utils.POST, request, username);
                dataOutputStream.writeObject(message);
                dataOutputStream.flush();

            } catch (Exception e) {
            }
        }

    }

    private void sendCoordinator(int type, String request, String username) {
        try {
            Message message = Utils.generateMessage(type, Utils.POST, request, username);
            coordinatorStream.writeObject(message);
            coordinatorStream.flush();

        } catch (IOException e) {
            //e.printStackTrace();
        }
    }

    class ServerClientHandler extends Thread {

        private Socket socket;
        private ObjectInputStream in;
        private ObjectOutputStream out;

        public ServerClientHandler(Socket client) {
            this.socket = client;
            try {
                in = new ObjectInputStream(socket.getInputStream());
                out = new ObjectOutputStream(socket.getOutputStream());
            } catch (Exception e) {
                e.getMessage();
            }
        }

        @Override
        public void run() {
            try {
                while (true) {
                    Message message = (Message) in.readObject();
                    System.out.println(message.toString());

                    if (message.getMethod().equals(Utils.GET)) {
                        if (message.getType() == Utils.PARTICIPANT_CONNECTION_REQUEST) {
                            userNames.add(message.getUsername());
                            streams.add(out);
                            sendCoordinator(Utils.PARTICIPANT_CONNECTION_REQUEST, Utils.CONNECT, message.getUsername());

                        } else if (message.getType() == Utils.COORDINATE_CONNECTION_REQUEST) {
                            coordinatorStream = out;
                        }
                    } else if (message.getMethod().equals(Utils.POST)) {
                        if (message.getType() == Utils.PARTICIPANT_REQUEST) {
                            if (message.getRequest().equals(Utils.ABORT)) {
                                sendCoordinator(Utils.PARTICIPANT_REQUEST, Utils.ABORT, message.getUsername());
                            } else if (message.getRequest().equals(Utils.COMMIT)) {
                                sendCoordinator(Utils.PARTICIPANT_REQUEST, Utils.COMMIT, message.getUsername());
                            }
                        } else if (message.getType() == Utils.COORDINATE_REQUEST) {
                            if (message.getRequest().equals(Utils.GLOBAL_ABORT)) {
                                SendDataAllParticipants(Utils.COORDINATE_REQUEST, Utils.GLOBAL_ABORT, Utils.COORDINATOR_NAME);
                            } else if (message.getRequest().equals(Utils.GLOBAL_COMMIT)) {
                                SendDataAllParticipants(Utils.COORDINATE_REQUEST, Utils.GLOBAL_COMMIT, Utils.COORDINATOR_NAME);
                            } else {
                                SendDataAllParticipants(Utils.COORDINATE_REQUEST, message.getRequest(), Utils.COORDINATOR_NAME);
                            }
                        }


                    }
                }

            } catch (Exception e) {
                //e.printStackTrace();
            }
        }
    }
}
