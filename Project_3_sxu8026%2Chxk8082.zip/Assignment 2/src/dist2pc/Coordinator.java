package dist2pc;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.*;
import java.util.Timer;

public class Coordinator extends JFrame {
    JLabel stateView;
    JTextField messageView;
    JButton sendBtn;
    JTextArea logArea;

    Socket socket;
    ObjectInputStream in;
    ObjectOutputStream out;
    ArrayList<String> participants;
    String state;
    HashMap<String, String> votes;
    Timer timer;
    boolean readyVote = true;

    public Coordinator() {
        super("Coordinate");
        initialize();
    }

    private void initialize() {
        JPanel rootPanel = new JPanel();
        rootPanel.setLayout(new BoxLayout(rootPanel, BoxLayout.Y_AXIS));
        rootPanel.setBorder(new EmptyBorder(10, 20, 10, 20));
        rootPanel.add(getStatePanel());
        rootPanel.add(Box.createRigidArea(new Dimension(0, 7)));
        rootPanel.add(getTopPanel());
        rootPanel.add(getLogArea());
        rootPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        add(rootPanel);
        setResizable(false);
        pack();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private JPanel getStatePanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout());
        stateView = new JLabel("Connecting server...");
        panel.add(stateView);
        return panel;
    }

    private JPanel getTopPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
        JLabel label = new JLabel("Enter message: ");
        messageView = new JTextField(11);
        sendBtn = new JButton("Send Vote");
        sendBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                sendVoteRequest();
            }
        });

        panel.add(label);
        panel.add(Box.createRigidArea(new Dimension(10, 0)));
        panel.add(messageView);
        panel.add(Box.createRigidArea(new Dimension(20, 0)));
        panel.add(sendBtn);

        return panel;
    }

    private JPanel getLogArea() {
        JPanel panel = new JPanel();
        logArea = new JTextArea(15, 35);
        logArea.setEditable(false);
        //logArea.setSize(new Dimension(400, 300));
        JScrollPane scrollPane = new JScrollPane(logArea);
        panel.add(scrollPane);
        return panel;
    }

    public void connect() {
        try {
            socket = new Socket(Utils.IP, Utils.PORT);
            participants = new ArrayList<>();
            votes = new HashMap<>();

            state = Utils.INIT;

            out = new ObjectOutputStream(socket.getOutputStream());
            in = new ObjectInputStream(socket.getInputStream());


            Message message = Utils.generateMessage(Utils.COORDINATE_CONNECTION_REQUEST, Utils.GET, Utils.CONNECT, Utils.COORDINATOR_NAME);
            out.writeObject(message);
            out.flush();

            stateView.setText("Connected to server.");

        } catch (IOException e) {
            stateView.setText("Server is down...");
            return;
        }
        new CoordinatorProcessor().start();
    }

    private void sendVoteRequest() {
        if(!readyVote){
            Utils.showMessage(this, "Please wait vote result");
            return;
        }
        String msg = messageView.getText().trim();

        if (msg.isEmpty()) {
            Utils.showMessage(this, "Please enter some valid string except just spaces");
        } else {
            try {
                Message message = Utils.generateMessage(Utils.COORDINATE_REQUEST, Utils.POST, msg, Utils.COORDINATOR_NAME);
                out.writeObject(message);

                readyVote = false;

                timer = new Timer();

                TimerTask checker = new TimerTask() {
                    @Override
                    public void run() {
                        int votecount = 0;
                        for (String participant : votes.keySet()) {
                            if (votes.get(participant).equals(Utils.COMMIT)) {
                                votecount++;
                            } else {
                                break;
                            }
                        }
                        if (votecount != votes.size()) {
                            logArea.append("Time Out. Not all participants voted.\n");
                            logArea.append("Global Abort.\n");

                            Message message = Utils.generateMessage(Utils.COORDINATE_REQUEST, Utils.POST, Utils.GLOBAL_ABORT, Utils.COORDINATOR_NAME);
                            try {
                                out.writeObject(message);
                                out.flush();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }

                            for (String client : votes.keySet()) {
                                votes.put(client, "");
                            }
                            state = Utils.ABORT;
                            readyVote = true;
                        }
                    }
                };
                timer.schedule(checker, 30000);

            } catch (IOException e1) {
                e1.printStackTrace();
            }
            messageView.setText("");
        }
    }

    public class CoordinatorProcessor extends Thread {
        @Override
        public void run() {
            try {
                while (true) {
                    Message message = (Message) in.readObject();
                    if (message.getMethod().equals(Utils.POST)) {
                        if (message.getRequest().equals(Utils.CONNECT) && message.getType() == Utils.PARTICIPANT_CONNECTION_REQUEST) {
                            String participantName = message.getUsername();
                            participants.add(participantName);
                            votes.put(participantName, "");
                            logArea.append("New participant is connected : " + participantName + "\n");
                        } else if (message.getType() == Utils.PARTICIPANT_REQUEST && message.getRequest().equals(Utils.ABORT)) {
                            String participantName = message.getUsername();
                            votes.put(participantName, Utils.ABORT);
                            state = Utils.ABORT;
                            logArea.append("Abort by client " + participantName + "\n");
                            logArea.append("One client " + participantName + " voted to Abort\n");

                            readyVote = true;

                            timer.cancel();
                            timer.purge();

                            Message sendMessage = Utils.generateMessage(Utils.COORDINATE_REQUEST, Utils.POST, Utils.GLOBAL_ABORT, Utils.COORDINATOR_NAME);
                            out.writeObject(sendMessage);
                            out.flush();

                            for (String client : votes.keySet()) {
                                votes.put(client, "");
                            }
                        } else if (message.getType() == Utils.PARTICIPANT_REQUEST && message.getRequest().equals(Utils.COMMIT)) {

                            String participantName = message.getUsername();
                            votes.put(participantName, Utils.COMMIT);
                            logArea.append("Commit vote by client: " + participantName + "\n");
                            int counter = 0;
                            for (String key : votes.keySet()) {
                                if (votes.get(key).equals(Utils.COMMIT)) {
                                    counter++;
                                } else {
                                    break;
                                }
                            }
                            if (counter == votes.size()) {
                                timer.cancel();
                                timer.purge();
                                readyVote = true;

                                logArea.append("All participants commit vote.\n");
                                state = Utils.COMMIT;

                                Message sendMessage = Utils.generateMessage(Utils.COORDINATE_REQUEST, Utils.POST, Utils.GLOBAL_COMMIT, Utils.COORDINATOR_NAME);
                                out.writeObject(sendMessage);
                                out.flush();

                                for (String client : votes.keySet()) {
                                    votes.put(client, "");
                                }
                            }
                        }
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        Coordinator coordinator = new Coordinator();
        coordinator.setVisible(true);
        coordinator.connect();
    }
}
