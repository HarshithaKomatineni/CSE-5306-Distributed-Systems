package dist2pc;

import java.io.Serializable;

public class Message implements Serializable {
    private int type;
    private String method;
    private String request;
    private String username;
    private String date;

    public void Message(){

    }

    public void setType(int type) {
        this.type = type;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public void setRequest(String request) {
        this.request = request;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getType() {
        return type;
    }

    public String getMethod() {
        return method;
    }

    public String getUsername() {
        return username;
    }

    public String getRequest() {
        return request;
    }

    public String getDate() {
        return date;
    }

    @Override
    public String toString(){
        StringBuilder builder = new StringBuilder();
        builder.append("Method: ").append(getMethod()).append("\n")
                .append("Request: ").append(getRequest()).append("\n")
                .append("User: ").append(getUsername()).append("\n")
                .append("Date: ").append(date).append("\n");
        return builder.toString();
    }
}
