package dist2pc;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.Socket;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.Pattern;

public class Participant extends JFrame {
    JTextField nameView;
    JButton connectBtn;
    JButton abortBtn;
    JButton commitBtn;
    JTextArea logArea;

    ObjectOutputStream out;
    ObjectInputStream in;
    Socket socket;
    String name;

    Timer timer;
    String state = "INIT";
    String data = "";
    boolean isConnected = false;
    public String regex = "^[a-zA-Z0-9]+$";

    public Participant(){
        super("Participant");
        initialize();
    }
    private void initialize(){
        state = Utils.INIT;
        JPanel rootPanel = new JPanel();
        rootPanel.setLayout(new BoxLayout(rootPanel, BoxLayout.Y_AXIS));
        rootPanel.setBorder(new EmptyBorder(10, 20, 10, 20));

        rootPanel.add(getTopPanel());
        rootPanel.add(getLogArea());
        rootPanel.add(getBottomArea());

        add(rootPanel);
        setResizable(false);
        pack();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    private JPanel getTopPanel(){
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
        JLabel label = new JLabel("Enter name: ");
        nameView = new JTextField(11);
        connectBtn = new JButton("Connect");
        connectBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                connectToServer();
            }
        });

        panel.add(label);
        panel.add(Box.createRigidArea(new Dimension(10, 0)));
        panel.add(nameView);
        panel.add(Box.createRigidArea(new Dimension(20, 0)));
        panel.add(connectBtn);

        return panel;
    }

    private JPanel getLogArea(){
        JPanel panel = new JPanel();
        logArea = new JTextArea(15, 35);
        logArea.setEditable(false);
        //logArea.setSize(new Dimension(400, 300));
        JScrollPane scrollPane = new JScrollPane(logArea);
        panel.add(scrollPane);
        return panel;
    }
    private JPanel getBottomArea(){
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
        abortBtn = new JButton("Abort");
        commitBtn = new JButton("Commit");

        abortBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                abort();
            }
        });

        commitBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                commit();
            }
        });

        panel.add(abortBtn);
        panel.add(Box.createRigidArea(new Dimension(30, 0)));
        panel.add(commitBtn);

        return panel;
    }

    private void connectToServer(){
        if (isConnected()) {
            Utils.showMessage(this, "You are already connected !");
        } else {
            name = nameView.getText().trim();
            //validate participant name
            if (name.isEmpty() || (!Pattern.matches(regex, name))) {
                Utils.showMessage(this, "Please enter an alphanumeric username to connect to server");
            } else {
                try {
                    socket = new Socket(Utils.IP, Utils.PORT);
                    out = new ObjectOutputStream(socket.getOutputStream());
                    in = new ObjectInputStream(socket.getInputStream());

                    //send server participant name and connection request
                    Message message = Utils.generateMessage(Utils.PARTICIPANT_CONNECTION_REQUEST, Utils.GET, Utils.CONNECT, name);
                    out.writeObject(message);
                    out.flush();

                    logArea.append("Connected to server.\n");
                    isConnected = true;

                } catch (Exception e) {
                    Utils.showMessage(this, "Server is down...");
                    return;
                }

                new Processor().start();

                timer = new Timer();
                TimerTask votingChecker = new TimerTask() {
                    @Override
                    public void run() {
                        if (data.trim().isEmpty() && state.equals(Utils.INIT)) {
                            logArea.append("Can not get voting request yet...\n");
                            state = Utils.ABORT;
                        }
                    }
                };
                timer.schedule(votingChecker, 35000);
            }
        }
    }

    private void commit(){
        if (state.equals(Utils.READY) || data == null || data.trim().isEmpty()) {
            Utils.showMessage(this, "Can't vote now");
        } else {

            try {
                Message message = Utils.generateMessage(Utils.PARTICIPANT_REQUEST, Utils.POST, Utils.COMMIT, name);
                out.writeObject(message);
                out.flush();

                logArea.append("Commit\n");
                state = Utils.READY;
                timer = new Timer();
                TimerTask commitChecker = new TimerTask() {

                    @Override
                    public void run() {
                        if (!state.equals(Utils.INIT)) {
                            //coordinate fail state
                            logArea.append("Can not get response from coordinate\n");
                            data = "";
                            state = Utils.ABORT;
                        }
                    }
                };
                timer.schedule(commitChecker, 50000);

            } catch (IOException e1) {
                e1.printStackTrace();
            }
        }
    }
    private void abort(){
        if (!(data == null || data.trim().isEmpty())) {
            try {
                Message message = Utils.generateMessage(Utils.PARTICIPANT_REQUEST, Utils.POST, Utils.ABORT, name);
                out.writeObject(message);
                out.flush();
                logArea.append("Abort vote\n");
                state = Utils.ABORT;
                data = "";
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        } else {
            Utils.showMessage(this, "Can't vote now");
        }
    }
    public class Processor extends Thread {
        @Override
        public void run() {
            try {
                while (true) {
                    Message message = (Message) in.readObject();
                    if (message.getMethod().equals(Utils.POST)) {
                        if(message.getType() == Utils.COORDINATE_REQUEST){
                            if (message.getType() == Utils.COORDINATE_REQUEST && message.getRequest().equals(Utils.GLOBAL_COMMIT)) {
                                state = Utils.COMMIT;
                                logArea.append("All participants committed votes\n");
                                data = "";
                            } else if (message.getType() == Utils.COORDINATE_REQUEST && message.getRequest().equals(Utils.GLOBAL_ABORT)) {
                                logArea.append("One client abort vote. Abort\n");
                                state = Utils.ABORT;
                                data = "";
                            } else {
                                data = message.getRequest();
                                logArea.append("New vote request: " + data+"\n");
                                timer.cancel();
                                timer.purge();
                            }
                        }

                    }
                }
            } catch (Exception e) {
                logArea.append("Server is down...");
            }
        }
    }

    private boolean isConnected(){
        return isConnected;
    }

    public static void main(String[] args) {
        Participant participant = new Participant();
        participant.setVisible(true);
    }
}
