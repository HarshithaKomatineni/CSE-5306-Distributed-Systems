package part2;

public class EventV {
    private int id;
    private int sourcePic;
    private int destPic;
    private int port;
    private int[] vector;

    public EventV(){

    }

    public void setId(int id) {
        this.id = id;
    }

    public void setSourcePic(int sourcePic) {
        this.sourcePic = sourcePic;
    }

    public void setDestPic(int destPic) {
        this.destPic = destPic;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public void setVector(int[] vector){
        this.vector = vector;
    }
    public int getId() {
        return id;
    }

    public int getPort() {
        return port;
    }

    public int getSourcePic() {
        return sourcePic;
    }

    public int getDestPic() {
        return destPic;
    }

    public int[] getVector(){
        return vector;
    }
    @Override
    public boolean equals(Object ev){
        return this.id == ((EventV)ev).getId();
    }
}
