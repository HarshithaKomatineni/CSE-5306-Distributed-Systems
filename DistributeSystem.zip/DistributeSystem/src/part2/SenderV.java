package part2;


import java.util.Random;

public class SenderV extends Thread {
    private final VectorClock vectorClock;
    private final ProcV pic;

    public SenderV(ProcV pic, VectorClock vectorClock){
        this.pic = pic;
        this.vectorClock = vectorClock;
    }
    public void run(){
        int time = 0;
        while(time <= vectorClock.getTotalTime()){
            //generate random delay
            int delay = getRandomNum(1, 10);
            //generate get random process and it will send event to this process
            int to_pic;
            do {
                to_pic = getRandomNum(1, vectorClock.getProcNum());
            } while (to_pic == pic.getId());

            EventV event = new EventV();
            synchronized (vectorClock){
                //get unique event id
                event.setId(vectorClock.getIncrement());
            }
            event.setSourcePic(pic.getId());
            event.setDestPic(to_pic);
            event.setPort(vectorClock.getPort());
            //apply vector clock rule, increase C
            synchronized (pic){
                pic.increaseClock();
                event.setVector(pic.getVector());
            }
            synchronized (vectorClock.getBuffer()){
                //send event
                vectorClock.getBuffer().get(to_pic).add(event);
            }
            time += delay;
        }
        //end end event
        pic.setEnd(true);
    }
    private int getRandomNum(int min, int max){
        Random random = new Random();
        return random.nextInt(max - min + 1) + min;
    }
}
