package part2;

import java.util.Arrays;
import java.util.Queue;

public class ReceiverV extends Thread {
    private VectorClock vectorClock;
    private final ProcV pic;

    public ReceiverV(ProcV pic, VectorClock vectorClock){
        this.vectorClock = vectorClock;
        this.pic = pic;
    }
    public void run(){
        Queue<EventV> event_queue = vectorClock.getBuffer().get(pic.getId());
        while(!vectorClock.isEnd() || !event_queue.isEmpty()){
            if(event_queue.isEmpty()) continue;
            EventV event = event_queue.poll();
            int[] vector = event.getVector();
            //set vector values
            for(int i = 0; i < vector.length; i++){
                if(i != pic.getId() - 1){
                    pic.setVectorValue(i, vector[i]);
                }
            }
            //apply vector clock rule
            int  clock = max(vector[pic.getId() - 1], pic.getVectorValue(pic.getId() - 1));
            print(event);
            //update local clock
            if(clock > pic.getVectorValue(pic.getId() - 1)){
                synchronized (pic){
                    pic.setVectorValue(pic.getId() - 1, clock);
                }
            }else{
                synchronized (pic){
                    pic.increaseClock();
                }
            }
        }

    }
    private int max(int a, int b){
        return Math.max(a, b);
    }

    private void print(EventV event){
        System.out.println("Process " + pic.getId() + ": Event " + event.getId() + ": Clock: " + Arrays.toString(pic.getVector()));
    }
}
