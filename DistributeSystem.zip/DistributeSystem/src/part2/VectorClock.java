package part2;


import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

public class VectorClock {
    private int PROC_NUM = 5;
    private int total_time = 100;
    private int port = 8088;
    private Map<Integer, Queue<EventV>> BUFFER = new HashMap<>();
    private List<ProcV> processes;
    private AtomicInteger incrementer = new AtomicInteger(1);

    public int getPort(){
        return this.port;
    }
    public int getProcNum(){
        return PROC_NUM;
    }
    public int getTotalTime(){
        return total_time;
    }
    public Map<Integer, Queue<EventV>> getBuffer() {
        return BUFFER;
    }
    public int getIncrement(){
        return incrementer.getAndIncrement();
    }
    public boolean isEnd(){
        for(ProcV proc : processes){
            if(!proc.isEnd()){
                return false;
            }
        }
        return true;
    }
    public void simulation(){
        processes = new ArrayList<>();
        //create processes
        for(int i = 0; i < getProcNum(); i++){
            ProcV proc = new ProcV(i + 1, this);
            proc.setVector(new int[getProcNum()]);
            processes.add(proc);
            BUFFER.put(i + 1, new LinkedList<>());
        }
        for(ProcV proc : processes){
            proc.work();
        }
    }
    public static void main(String[] args) throws Exception {
        System.out.println("------- Vector Clock ------------");
        VectorClock lamport = new VectorClock();
        lamport.simulation();
    }
}
