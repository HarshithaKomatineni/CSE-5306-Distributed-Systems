package part2;



public class ProcV {
    private int id;
    private VectorClock vectorClock;
    private SenderV sender;
    private ReceiverV receiver;
    private boolean end;
    private int[] vector;

    public ProcV(int id, VectorClock vectorClock){
        this.id = id;
        this.vectorClock = vectorClock;
        end = false;
    }

    public void setId(int id) {
        this.id = id;
    }


    public void increaseClock(){
        vector[id - 1] = vector[id - 1] + 1;
    }
    public void setVectorValue(int i, int val){
        vector[i] = val;
    }
    public void setEnd(boolean end) {
        this.end = end;
    }

    public void setVector(int[] vector) {
        this.vector = vector;
    }

    public int getId() {
        return id;
    }

    public boolean isEnd() {
        return end;
    }

    public int[] getVector() {
        return vector;
    }
    public int getVectorValue(int i){
        return vector[i];
    }
    public void work(){
        sender = new SenderV(this, vectorClock);
        receiver = new ReceiverV(this, vectorClock);
        //start simulation
        sender.start();
        receiver.start();
    }
}
