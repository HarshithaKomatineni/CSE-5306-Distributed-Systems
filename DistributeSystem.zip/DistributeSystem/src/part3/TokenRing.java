package part3;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class TokenRing {
    private int procNum = 5;
    private int ring;
    private List<ProcT> processes;
    private int time = 0;
    private String file = "test.txt";


    private void createFile(){
        BufferedWriter writer = null;
        try{
            writer = new BufferedWriter(new FileWriter(file));
            writer.write("1");
        }catch (Exception e){

        }finally {
            if(writer != null){
                try{
                    writer.close();
                }catch (Exception ex){

                }
            }
        }
    }
    public int getProcNum(){
        return procNum;
    }
    public void nextRing(){
        if(ring < procNum){
            ring++;
        } else{
            ring = 1;
        }
        time++;
    }
    public int getTime(){
        return time;
    }
    public int getRing(){
        return ring;
    }
    public void start(){
        //create file
        createFile();
        processes = new ArrayList<>();
        //create processes
        for(int i = 0; i < getProcNum(); i++){
            ProcT proc = new ProcT(i + 1, file, this);
            processes.add(proc);
        }
        ring = 1;
        for(ProcT proc : processes){
            proc.start();
        }
    }
    public static void main(String[] args) throws Exception {
        System.out.println("------- Token Ring ------------");
        TokenRing token = new TokenRing();
        token.start();
    }
}
