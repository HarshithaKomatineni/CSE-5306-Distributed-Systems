package part3;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;

public class ProcT extends Thread {

    private int id;
    private String file;
    private final TokenRing tokenRing;

    public ProcT(int id, String file, TokenRing tokenRing){
        this.id = id;
        this.file = file;
        this.tokenRing = tokenRing;
    }
    private int readFile(){
        BufferedReader reader = null;
        try{
            reader = new BufferedReader(new FileReader(file));
            String line = reader.readLine();
            return Integer.parseInt(line.trim());
        }catch (Exception e){

        }finally {
            if(reader != null){
                try{
                    reader.close();
                }catch (Exception ex){

                }
            }
        }
        return -1;
    }
    private void writeFile(int value){
        BufferedWriter writer = null;
        try{
            writer = new BufferedWriter(new FileWriter(file));
            writer.write(String.valueOf(value));
        }catch (Exception e){

        }finally {
            if(writer != null){
                try{
                    writer.close();
                }catch (Exception ex){

                }
            }
        }
    }
    public void run(){
        try{
            while (tokenRing.getTime() != 500) {
                if (tokenRing.getRing() == id) {
                    //open file and increase number
                    int value = readFile();
                    writeFile(value + 1);
                    tokenRing.nextRing();
                    System.out.println("Process " + id + " increase number in file. Value : " + (value + 1) + " Time: " + tokenRing.getTime());
                }else{
                    Thread.yield();
                }
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
