package part1;

public class EventL {
    private int id;
    private int pic;
    private int port;
    private int c; //counter

    public EventL(){

    }

    public void setId(int id) {
        this.id = id;
    }

    public void setPic(int pic) {
        this.pic = pic;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public void setCounter(int c){
        this.c = c;
    }

    public int getId() {
        return id;
    }

    public int getPic() {
        return pic;
    }

    public int getPort() {
        return port;
    }

    public int getCounter(){
        return c;
    }
    @Override
    public boolean equals(Object ev){
        return this.id == ((EventL)ev).getId();
    }
}
