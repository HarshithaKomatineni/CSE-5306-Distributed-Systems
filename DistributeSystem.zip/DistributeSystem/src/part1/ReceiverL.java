package part1;

import java.util.Queue;

public class ReceiverL extends Thread {
    private Lamport lamport;
    private final ProcL pic;
    public ReceiverL(ProcL pic, Lamport lamport){
        this.lamport = lamport;
        this.pic = pic;
    }
    public void run(){
        Queue<EventL> event_queue = lamport.getBuffer().get(pic.getId());
        while(!lamport.isEnd() || !event_queue.isEmpty()){
            if(event_queue.isEmpty()) continue;
            EventL event = event_queue.poll();
            int counter = event.getCounter();
            //apply lamport rule
            int  clock = max(counter + 1, pic.getClock());
            print(event, clock);
            //update local clock
            if(clock > pic.getClock()){
                synchronized (pic){
                    pic.setClock(clock);
                }
            }else{
                synchronized (pic){
                    pic.increaseClock();
                }
            }
        }

    }
    private int max(int a, int b){
        return Math.max(a, b);
    }
    private void print(EventL event, int clock){
        System.out.println("Process " + event.getPic() + ": Event " + event.getId() + ": Timestamp: " + clock);
    }
}
