package part1;


public class ProcL {
    private int id;
    private Lamport lamport;
    private SenderL sender;
    private ReceiverL receiver;
    private boolean end;
    private int clock;

    public ProcL(int id, Lamport lamport){
        this.id = id;
        this.lamport = lamport;
        end = false;
        clock = 0;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setClock(int clock) {
        this.clock = clock;
    }

    public void increaseClock(){
        clock++;
    }
    public void setEnd(boolean end) {
        this.end = end;
    }

    public int getId() {
        return id;
    }

    public int getClock() {
        return clock;
    }

    public boolean isEnd() {
        return end;
    }

    public void work(){
        sender = new SenderL(this, lamport);
        receiver = new ReceiverL(this, lamport);
        //start simulation
        sender.start();
        receiver.start();
    }
}
