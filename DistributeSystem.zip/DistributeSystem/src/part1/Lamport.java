package part1;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

public class Lamport {
    private int PROC_NUM = 10;
    private int total_time = 100;
    private int port = 8088;
    private Map<Integer, Queue<EventL>> BUFFER = new HashMap<>();
    private List<ProcL> processes;
    private AtomicInteger incrementer = new AtomicInteger(1);

    public int getPort(){
        return this.port;
    }
    public int getProcNum(){
        return PROC_NUM;
    }
    public int getTotalTime(){
        return total_time;
    }
    public Map<Integer, Queue<EventL>> getBuffer() {
        return BUFFER;
    }
    public int getIncrement(){
        return incrementer.getAndIncrement();
    }
    public boolean isEnd(){
        for(ProcL proc : processes){
            if(!proc.isEnd()){
                return false;
            }
        }
        return true;
    }
    public void simulation(){
        processes = new ArrayList<>();
        //create processes
        for(int i = 0; i < getProcNum(); i++){
            ProcL proc = new ProcL(i + 1, this);
            processes.add(proc);
            BUFFER.put(i + 1, new LinkedList<>());
        }
        for(ProcL proc : processes){
            proc.work();
        }
    }
    public static void main(String[] args) throws Exception {
        System.out.println("------- Lamport Clock ------------");
        Lamport lamport = new Lamport();
        lamport.simulation();
    }
}
