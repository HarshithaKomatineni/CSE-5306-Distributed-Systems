package part1;

import java.util.Random;

public class SenderL extends Thread {
    private final Lamport lamport;
    private final ProcL pic;

    public SenderL(ProcL pic, Lamport lamport){
        this.pic = pic;
        this.lamport = lamport;
    }
    public void run(){
        int time = 0;
        while(time <= lamport.getTotalTime()){
            //generate random delay
            int delay = getRandomNum(1, 10);
            //generate get random process and it will send event to this process
            int to_pic;
            do {
                to_pic = getRandomNum(1, lamport.getProcNum());
            } while (to_pic == pic.getId());

            EventL event = new EventL();
            synchronized (lamport){
                //get unique event id
                event.setId(lamport.getIncrement());
            }
            event.setPic(to_pic);
            event.setPort(lamport.getPort());
            //apply lamport rule, increase C
            synchronized (pic){
                pic.increaseClock();
                event.setCounter(pic.getClock());
            }
            synchronized (lamport.getBuffer()){
                //send event
                lamport.getBuffer().get(to_pic).add(event);
            }
            time += delay;
        }
        //end end event
        pic.setEnd(true);
    }
    private int getRandomNum(int min, int max){
        Random random = new Random();
        return random.nextInt(max - min + 1) + min;
    }
}
